package ro.siit.dealership;

public class Kia extends Car {
    String manufacturer;
    String model;
    int productionYear;
    Boolean isNew;
    float price;
}
