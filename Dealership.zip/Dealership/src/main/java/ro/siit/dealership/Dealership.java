package ro.siit.dealership;

/**
 * @author x-RauL-x
 */

public class Dealership {
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
     Customer [] customers = new Customer[1];
     Car [] cars = new Car[1];
     String dealershipName;
     GreenBonusProgram greenBonusProgram = new GreenBonusProgram();

    }
}


