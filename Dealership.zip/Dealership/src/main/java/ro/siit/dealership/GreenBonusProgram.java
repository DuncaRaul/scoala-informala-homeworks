package ro.siit.dealership;

/**
 *
 */

public class GreenBonusProgram {
    float budget;
    String [] purchaseHistory;
    Boolean approved;
}
