package ro.siit.dealership;

public class Volkswagen extends Car {
    String manufacturer;
    String model;
    int productionYear;
    Boolean isNew;
    float price;
}
