package ro.siit.dealership;

/**
 *
 */

public class Car {
    String motor;
    String bateriesl;
    String consumption;
    int stock;
}
