package ro.siit.dealership;

/**
 *
 */

public class Customer {
    String name;
    int id;
}
